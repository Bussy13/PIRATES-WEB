<?php

//Inlcuir el archivo de conexion con la Base de datos
include ("conexion.php");

//Creo dos variables para el usario y contraseña del name="" en el form
$users = $_POST["usuario"];
$claves  = $_POST["contraseña"];

//Para iniciar sesión

//La varibale de la query nos permite ejecutar esa sentencia en la base de datos

$query = mysqli_query($conn, "SELECT * FROM clientes WHERE usuario ='$users' and contraseña = '$claves'");

//La varibale de la nr mysqli_num_rows(variable de la query) nos permite mirar los registros de la tabla

$nr 		= mysqli_num_rows($query);  
	
//If la varible nr es igual a 1 nos permitira logearnos tan valdria poner if ($nr > 0)  

if ($nr == 1)  
	{ 
	echo "<script> alert('Usuario logueado.');window.location= 'logeado.php' </script>";

	}
else
	{
	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
	}

?>

