<?php

 session_start();

include('conexion.php');

$users = $_POST["usuario"];
$claves 	= $_POST["contraseña"];

//Para iniciar sesión

$queryusuario = mysqli_query($conn,"SELECT * FROM clientes WHERE usuario ='$users' and contraseña = '$claves'");
$nr 		= mysql_num_rows($queryusuario);  
	
if ($nr == 1)  
	{ 
	echo "<script> alert('Usuario logueado.');window.location= 'logeado.php' </script>";

	}
else
	{
	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
	}


if ($nr == 1){
    session_start();
    $_SESSION['usuario'] = $users;
}

?>

