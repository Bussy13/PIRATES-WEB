<?php
// Inciamos Sesion
session_start(); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Link mi CSS -->
  <link rel="stylesheet" href="">
    <!-- Icono -->
    <link rel="icon" href="./favicon.jpg" type="image/x-icon">
  <title>The Pirates</title>
</head>
<body>
       <div class="container col-12 justify-content-start pt-5 d-flex">
       <a href="index.html"><img src="1.png" class="img-fluid h-8"></a>
    </div>
     <div class="text">
        <h1><?php echo $_SESSION["usuario"]; ?></h1>
        <h4>Bienvenido</h4>
</div>
</body>
   
</html>