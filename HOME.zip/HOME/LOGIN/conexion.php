<?php

$servidor="localhost";
$root="root";
$clave="root";
$baseDeDatos="pirates";

$conn = mysqli_connect($servidor, $root, $clave, $baseDeDatos);

if(!$conn){
echo"Error en la conexion con el servidor";
}  


?>




